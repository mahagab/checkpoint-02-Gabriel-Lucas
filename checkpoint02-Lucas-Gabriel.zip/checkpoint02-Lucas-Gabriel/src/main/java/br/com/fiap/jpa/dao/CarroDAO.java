package br.com.fiap.jpa.dao;

import br.com.fiap.jpa.entity.Carro;

public interface CarroDAO extends GenericDAO<Carro, Long>{

}
