package br.com.fiap.jpa;

import java.util.List;

import br.com.fiap.jpa.entity.Acessorio;
import br.com.fiap.jpa.entity.Carro;
import br.com.fiap.jpa.entity.Modelo;
import br.com.fiap.jpa.service.impl.AcessorioServiceImpl;
import br.com.fiap.jpa.service.impl.CarroServiceImpl;
import br.com.fiap.jpa.service.impl.ModeloServiceImpl;

public class App {
	
	public static void main(String[]args) {
		

		ModeloServiceImpl modelos = ModeloServiceImpl.getInstance();
		
		AcessorioServiceImpl acessorios = AcessorioServiceImpl.getInstance();
		
		CarroServiceImpl carros = CarroServiceImpl.getInstance();
		
		
		
		Carro carro = new Carro("COD7I89", "Preto", "TZR51456YI15HY58695YIFC");

		Acessorio acessorio = new Acessorio("Calota");
		Acessorio acessorio2 = new Acessorio("Filtro de Ar");
		
		Modelo modelo = new Modelo("Ix35");
		
		acessorios.inserir(acessorio);
		acessorios.inserir(acessorio2);
		carros.inserir(carro);
		modelos.inserir(modelo);
		
		carro.setModelo(modelo);
	

	}

}
